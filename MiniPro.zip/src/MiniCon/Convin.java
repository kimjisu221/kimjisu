package MiniCon;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Convin extends JFrame {

	public static void main(String[] args) {
		new Convin();

	}

	public Convin() {
		JFrame frame = new JFrame("main");
		frame.setBounds(500, 100, 800, 800);
		frame.setLayout(new BorderLayout());
		frame.setDefaultCloseOperation(frame.DISPOSE_ON_CLOSE);
		frame.setBackground(Color.WHITE);
		JPanel panel1 = new JPanel();
		panel1.setLayout(null);
		
		ImageIcon img = new ImageIcon("images/maintitle.png");
		JLabel label = new JLabel(img);
		label.setIcon(img);
		panel1.setLocation(10, 80);
		panel1.add(label);
		panel1.setBackground(Color.WHITE);

		JPanel panel2 = new JPanel();
		panel2.setLayout(new BorderLayout());
		panel2.setBackground(Color.WHITE);

		JButton b2 = new JButton("관리 페이지로");
		b2.setFont(new Font("gothic", Font.BOLD, 20));
		b2.setBounds(468, 8, 80, 30);
		b2.setSize(100, 100);
		b2.addActionListener(new Maingo());

		b2.setBackground(Color.decode("#B07E7A"));
		b2.setForeground(Color.WHITE);

		panel2.add(label, BorderLayout.NORTH);
		panel2.add(b2, BorderLayout.SOUTH);

		frame.add(panel1, BorderLayout.NORTH);
		frame.add(panel2, BorderLayout.SOUTH);

		frame.setVisible(true);

	}

	class Maingo implements ActionListener { // 버튼 키 눌리면 패널 2번 호출
		@Override
		public void actionPerformed(ActionEvent e) {
			new FrameTest();
//	       setVisible(false);
		}
	}

}
