package MiniCon;

public class Storage {
	
	private int cokenum; //콜라의 개수
	private int ramannum; //라면의 개수
	private int cokkienum; //쿠키의 개수
	
	Storage(int cokenum, int ramannum, int cokkienum){
		this.cokenum = cokenum;
		this.ramannum = ramannum;
		this.cokkienum = cokkienum;
	}
	void setCokenum(int cokenum) {	//콜라의 개수를 설정
		this.cokenum = cokenum;
	}					
	int getCokenum() {	//현재 콜라의 개수를 리턴
		return cokenum;	
	}
	void setRamannum(int ramannum) {	//라면의 개수를 설정
		this.ramannum = ramannum;
	}
	int getRamannum() {		//라면의 개수를 리턴
		return ramannum;
	}
	void setCokkienum(int cokkienum) {	//쿠키의 개수를 설정
		this.cokkienum = cokkienum;
	}
	int getCokkienum() {	//쿠키의 개수를 리턴
		return cokkienum;
	}
}
