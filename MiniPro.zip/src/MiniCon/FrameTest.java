package MiniCon;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.LinkedList;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.LineBorder;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;




import MiniCon.*;

public class FrameTest extends JFrame implements ActionListener {

	ImageIcon title = new ImageIcon("images/title.png");
	ImageIcon exit = new ImageIcon("images/exit.png");
	ImageIcon one = new ImageIcon("images/1.png");
	ImageIcon two = new ImageIcon("images/2.png");
	ImageIcon thr = new ImageIcon("images/3.png");
	ImageIcon four = new ImageIcon("images/4.png");
	ImageIcon fiv = new ImageIcon("images/5.png");
	ImageIcon six = new ImageIcon("images/6.png");
	ImageIcon sev = new ImageIcon("images/7.png");
	ImageIcon eig = new ImageIcon("images/8.png");
	ImageIcon nin = new ImageIcon("images/9.png");

	JButton jbt1 = new JButton(one);
	JButton jbt2 = new JButton(two);
	JButton jbt3 = new JButton(thr);
	JButton jbt4 = new JButton(four);
	JButton jbt5 = new JButton(fiv);
	JButton jbt6 = new JButton(six);
	JButton jbt7 = new JButton(sev);
	JButton jbt8 = new JButton(eig);
	JLabel btn = new JLabel(title);
	JButton jbt9 = new JButton(nin);
	JButton jbt10 = new JButton(exit);

	JTextArea textarea = new JTextArea();
	JScrollPane scroll = new JScrollPane(textarea);
	
	
	String FILE_NAME="test.txt";

	public FrameTest() {

		JFrame frame = new JFrame("미니 편의점");
		frame.setLayout(new BorderLayout());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(1050, 800); // 가로를 500, 세로를 300픽셀로 지정

		frame.setBackground(Color.WHITE);

		LineBorder t = new LineBorder(Color.WHITE);

		JPanel panel1 = new JPanel();
		panel1.setLayout(new FlowLayout());

		JLabel title = new JLabel("종진이와 아이들");
		title.setFont(new Font("BMJUA_TTF", Font.BOLD, 50));

		btn.setSize(100, 100);

		

		panel1.add(btn);
		panel1.add(title);
		panel1.add(jbt10);
		panel1.setBackground(Color.white);

		JPanel panel2 = new JPanel();
		panel2.setLayout(null);
		
		JPanel panel3=new JPanel();
		panel3.setLayout(new FlowLayout());
		
		

		jbt1.setLocation(50, 50);
		jbt1.setSize(200, 100);

		jbt2.setLocation(260, 50);
		jbt2.setSize(200, 100);

		jbt3.setLocation(470, 50);
		jbt3.setSize(200, 100);

		jbt4.setLocation(50, 200);
		jbt4.setSize(200, 100);

		jbt5.setLocation(260, 200);
		jbt5.setSize(200, 100);

		jbt6.setLocation(470, 200);
		jbt6.setSize(200, 100);

		jbt7.setLocation(50, 350);
		jbt7.setSize(200, 100);

		jbt8.setLocation(260, 350);
		jbt8.setSize(200, 100);

		jbt9.setLocation(470, 350);
		jbt9.setSize(200, 100);
		
		jbt1.setBorderPainted(false);
		jbt1.setContentAreaFilled(false);
		jbt1.setFocusPainted(false);
		
		jbt2.setBorderPainted(false);
		jbt2.setContentAreaFilled(false);
		jbt2.setFocusPainted(false);
		
		jbt3.setBorderPainted(false);
		jbt3.setContentAreaFilled(false);
		jbt3.setFocusPainted(false);
		
		jbt4.setBorderPainted(false);
		jbt4.setContentAreaFilled(false);
		jbt4.setFocusPainted(false);
		
		jbt5.setBorderPainted(false);
		jbt5.setContentAreaFilled(false);
		jbt5.setFocusPainted(false);
		
		jbt6.setBorderPainted(false);
		jbt6.setContentAreaFilled(false);
		jbt6.setFocusPainted(false);
		
		jbt7.setBorderPainted(false);
		jbt7.setContentAreaFilled(false);
		jbt7.setFocusPainted(false);
		
		jbt8.setBorderPainted(false);
		jbt8.setContentAreaFilled(false);
		jbt8.setFocusPainted(false);
		
		jbt9.setBorderPainted(false);
		jbt9.setContentAreaFilled(false);
		jbt9.setFocusPainted(false);

		jbt10.setBorderPainted(false);
		jbt10.setContentAreaFilled(false);
		jbt10.setFocusPainted(false);
		
		

		panel2.add(jbt1);
		panel2.add(jbt2);
		panel2.add(jbt3);
		panel2.add(jbt4);
		panel2.add(jbt5);
		panel2.add(jbt6);
		panel2.add(jbt7);
		panel2.add(jbt8);
		panel2.add(jbt9);
		
	    panel3.add(textarea);

		panel2.setBackground(Color.decode("#E8CF90"));
		panel3.setBackground(Color.decode("#B07E7A"));

		jbt1.addActionListener(this);
		jbt2.addActionListener(this);
		jbt3.addActionListener(this);
		jbt4.addActionListener(this);
		jbt5.addActionListener(this);
		jbt6.addActionListener(this);
		jbt7.addActionListener(this);
		jbt8.addActionListener(this);
		jbt9.addActionListener(this);
		jbt10.addActionListener(this);

		frame.add(panel1, BorderLayout.NORTH);
		frame.add(panel2, BorderLayout.CENTER);
		frame.add(panel3, BorderLayout.EAST);

		frame.setVisible(true);// 화면 창 띄움
		
		

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

		// 액션 리스너 재정의
		if (e.getSource().equals(jbt1)) {
			plusMenu();
		} else if (e.getSource().equals(jbt2)) {
			reWriteStorage();
		} else if (e.getSource().equals(jbt3)) {
			delStorage();
		} else if (e.getSource().equals(jbt4)) {
			conStorate();
		} else if (e.getSource().equals(jbt5)) {
			sellStorate();
		} else if (e.getSource().equals(jbt6)) {
			moneyStorage();
		} else if (e.getSource().equals(jbt7)) {
			showStorage();
		} else if (e.getSource().equals(jbt8)) {
			reMoney();
		} else if (e.getSource().equals(jbt9)) {
			qrCode();
		} else if (e.getSource().equals(jbt10)) {
			exit();
		}

	}

	Storage mS = new Storage(100, 100, 100);

	String str = "현재 재고입니다.";
	String cok = "\n1. 콜라(1000원) : ";
	String ram = "\n2. 라면(1500원) : ";
	String coki = "\n3. 쿠키(1200원) : "; // 매번 글씨쓰기 귀찮아서 변수로 지정했음

	String inputDia; // jop에서 입력받을 문자열 변수 하나 지정

	int cokenum_in;// 각 메뉴의 수량변수
	int ramannum_in;
	int cokkienum_in; // int형의 추가할만큼의 데이터를 저장할 변수 설정
	int cokemoney = 0;// 각 메뉴의 돈변수
	int ramanmoney = 0;
	int cokkiemoney = 0;
	int cokecnt = 0;// 각 메뉴의 환불용 변수
	int ramancnt = 0;
	int cokkiecnt = 0;
	int summoney = 0;
	
	
	 void addLog(String log)

	   {

	      textarea.setBounds(100, 50, 100, 500);
	      
	      textarea.append(log + "\n");  // 로그 내용을 JTextArea 위에 붙여주고

	      textarea.setCaretPosition(textarea.getDocument().getLength());  // 맨아래로 스크롤한다.
	      
	      
			try {
				FileInputStream fis = new FileInputStream("C:\\jisu\\abc\\test.txt");
				InputStreamReader reader=new InputStreamReader(fis,"UTF-8");
				FileOutputStream fos = new FileOutputStream("C:\\jisu\\abc\\test2.txt", true); 
				BufferedReader in = new BufferedReader(reader);
				
				String str=log+"\n";
				byte[] by=str.getBytes();
				
				fos.write(by);
	            fos.flush();
				
				int data = 0;
				
				
				while((data = in.read())!= -1){
					fos.write(data);
				}
				fis.close();
				fos.close();
				in.close();
				

			}catch ( IOException e ) {
				e.getStackTrace();
			

			}
			

	   }


	 void plusMenu() {   //재고를 추가하는 함수
	       inputDia = JOptionPane.showInputDialog(str+cok+ mS.getCokenum() + "개" +ram+mS.getRamannum() + "개" +coki+mS.getCokkienum() + "개"
	                                   +"\n 어떤 메뉴의 재고를 추가하시겠습니까?");
	       if(inputDia.equals("콜라") || inputDia.equals("1")) {   //만약 콜라라는 단어를 입력하면
	           inputDia = JOptionPane.showInputDialog("콜라에 얼만큼 추가하시겠습니까?");
	           cokenum_in =  Integer.parseInt(inputDia);   //콜라에 입력값만큼의 정수값을 추가
	           
	           mS.setCokenum(mS.getCokenum()+cokenum_in);
	           JOptionPane.showMessageDialog(null, "재고가 추가되었습니다.");

	           addLog("콜라의 재고가 "+cokenum_in+"만큼 추가되었습니다.");
	           
	        
	       }
	       else if(inputDia.equals("라면") || inputDia.equals("2")) {
	           inputDia = JOptionPane.showInputDialog("라면에 얼만큼 추가하시겠습니까?");
	           ramannum_in =  Integer.parseInt(inputDia);
	           
	           mS.setRamannum(mS.getRamannum()+ramannum_in);
	           JOptionPane.showMessageDialog(null, "재고가 추가되었습니다.");

	           addLog("라면의 재고가 "+ramannum_in+"만큼 추가되었습니다.");
	       }
	       else if(inputDia.equals("쿠키") || inputDia.equals("3")) {
	           inputDia = JOptionPane.showInputDialog("쿠키에 얼만큼 추가하시겠습니까?");
	           cokkienum_in =  Integer.parseInt(inputDia);
	           
	           mS.setCokkienum(mS.getCokkienum()+cokkienum_in);
	           JOptionPane.showMessageDialog(null, "재고가 추가되었습니다.");
	           addLog("쿠키의 재고가 "+cokkienum_in+"만큼 추가되었습니다.");
	       }
	       else {
	           JOptionPane.showMessageDialog(null, "올바른 값을 입력해주세요.");
	       }
	   }
	   
	   void reWriteStorage() { //재고를 수정하는 함수
	       inputDia = JOptionPane.showInputDialog(str+cok+ mS.getCokenum() + "개" +ram+mS.getRamannum() + "개" +coki+mS.getCokkienum() + "개"
	               +"\n 어떤 메뉴의 재고를 수정하시겠습니까?");
	       if (inputDia.equals("콜라") || inputDia.equals("1")) {
	           inputDia = JOptionPane.showInputDialog("콜라의 개수를 몇 개로 수정하시겠습니까?");
	           cokenum_in = Integer.parseInt(inputDia);
	           
	           mS.setCokenum(cokenum_in);
	           JOptionPane.showMessageDialog(null, "콜라의 재고가 " + mS.getCokenum() + "개로 수정되었습니다.");
	           addLog("콜라의 재고가 "+mS.getCokenum()+"로 수정되었습니다.");
	       }
	       else if (inputDia.equals("라면") || inputDia.equals("2")) {
	           inputDia = JOptionPane.showInputDialog("라면의 개수를 몇 개로 수정하시겠습니까?");
	           ramannum_in = Integer.parseInt(inputDia);
	           
	           mS.setRamannum(ramannum_in);
	           JOptionPane.showMessageDialog(null, "라면의 재고가 " + mS.getRamannum() + "개로 수정되었습니다.");
	           addLog("라면의 재고가 "+mS.getRamannum()+"로 수정되었습니다.");
	       }
	       else if (inputDia.equals("쿠키") || inputDia.equals("3")) {
	           inputDia = JOptionPane.showInputDialog("쿠키의 개수를 몇 개로 수정하시겠습니까?");
	           cokkienum_in = Integer.parseInt(inputDia);
	           
	           mS.setCokkienum(cokkienum_in);
	           JOptionPane.showMessageDialog(null, "쿠키의 재고가 " + mS.getCokkienum() + "개로 수정되었습니다.");
	           addLog("쿠키의 재고가 "+mS.getCokkienum()+"로 수정되었습니다.");
	       }
//	     else if () {
//	         
//	     }
	       else {
	           JOptionPane.showMessageDialog(null, "올바른 값을 입력해주세요.");
	       }

	   }
	   
	   void delStorage() { //재고를 삭제하는 함수
	       inputDia = JOptionPane
	               .showInputDialog("\n1. 콜라 (1,000원)" + "\n2. 라면 (1,500원)" + "\n3. 쿠키 (1,200원)" + "\n 어떤 메뉴의 재고를 삭제하시겠습니까?");

	         if (inputDia.equals("콜라") || inputDia.equals("1")) { // 만약 콜라라는 단어를 입력하면

	            inputDia = JOptionPane.showInputDialog("삭제하고 싶은 수량을 적으시오.");
	            cokenum_in = Integer.parseInt(inputDia);
	            ; // 콜라에 입력값만큼의 정수값을 추가
	            if (cokenum_in <= mS.getCokenum()) {
	               mS.setCokenum(mS.getCokenum() - cokenum_in);
	               JOptionPane.showMessageDialog(null, 
	                       "콜라 재고가 " + cokenum_in + "개 만큼 삭제되어 총 수량이 " + mS.getCokenum() + "개 입니다.");
	               addLog("콜라의 재고가 "+cokenum_in+"만큼 삭제되었습니다.");
	            } else {
	               JOptionPane.showMessageDialog(null, "삭제하고 싶은 수량이 총 수량보다 많습니다!");
	            }
	         } else if (inputDia.contentEquals("라면") || inputDia.equals("2")) {
	            inputDia = JOptionPane.showInputDialog("삭제하고 싶은 수량을 적으시오.");
	            ramannum_in = Integer.parseInt(inputDia);
	            
	            
	            if (ramannum_in <= mS.getRamannum()) {
	               mS.setRamannum(mS.getRamannum() - ramannum_in);
	               JOptionPane.showMessageDialog(null,
	                     "라면 재고가 " + ramannum_in + "개 만큼 삭제되어 총 수량이"  + mS.getRamannum() + "개 입니다.");
	               addLog("라면의 재고가 "+ramannum_in+"만큼 삭제되었습니다.");
	            } else {
	               JOptionPane.showMessageDialog(null, "삭제하고 싶은 수량이 총 수량보다 많습니다!");
	            }
	         } else if (inputDia.contentEquals("쿠키") || inputDia.equals("3")) {
	            inputDia = JOptionPane.showInputDialog("삭제하고 싶은 수량을 적으시오.");
	            cokkienum_in = Integer.parseInt(inputDia);
	            ;

	            if (cokkienum_in <= mS.getCokkienum()) {
	               mS.setCokkienum(mS.getCokkienum() - cokkienum_in);
	               JOptionPane.showMessageDialog(null,
	                     "쿠키 재고가 " + cokkienum_in + "개 만큼 삭제되어 총 수량이 " + mS.getCokkienum() + "개 입니다.");
	               addLog("쿠키의 재고가 "+cokkienum_in+"만큼 삭제되었습니다.");
	            } else {
	               JOptionPane.showMessageDialog(null, "삭제하고 싶은 수량이 총 수량보다 많습니다!");
	            }
	         } else {
	            JOptionPane.showMessageDialog(null, "올바른 값을 입력해주세요.");
	         }
	   }
	   
	   void conStorate() { //재고를 조회하는 함수
	       inputDia = JOptionPane
	               .showInputDialog("\n1. 콜라 (1,000원)" + "\n2. 라면 (1,500원)" + "\n3. 쿠키 (1,200원)" + "\n 어떤 메뉴의 재고를 조회 하시겠습니까?");
	         if (inputDia.equals("콜라") || inputDia.equals("1")) {
	            JOptionPane.showMessageDialog(null, "콜라의 재고량 : " + mS.getCokenum() + "개");
	            addLog("콜라의 재고는 "+mS.getCokenum()+"입니다.");
	         } else if (inputDia.equals("라면") || inputDia.equals("2")) {
	            JOptionPane.showMessageDialog(null, "라면의 재고량 : " + mS.getRamannum() + "개");
	            addLog("라면의 재고는 "+mS.getRamannum()+"입니다.");
	         } else if (inputDia.equals("쿠키") || inputDia.equals("3")) {
	            JOptionPane.showMessageDialog(null, "쿠키의 재고량 : " + mS.getCokkienum() + "개");
	            addLog("쿠키의 재고는 "+mS.getCokkienum()+"입니다.");
	         } else {

	            JOptionPane.showMessageDialog(null, "올바른 값을 입력해주세요.");

	         }
	   }
	   
	   void sellStorate() {    //판매하는 함수
	       inputDia = JOptionPane.showInputDialog(str + cok + mS.getCokenum() + "개"  + ram + mS.getRamannum() + "개"  + coki
	               + mS.getCokkienum() + "개"  + "\n 어떤 메뉴를 판매하시겠습니까?");
	         if (inputDia.equals("콜라") || inputDia.equals("1")) { // 만약 콜라라는 단어를 입력하면
	            inputDia = JOptionPane.showInputDialog("판매할 수량을 입력하세요.");
	            cokenum_in = Integer.parseInt(inputDia); // 콜라에 입력값만큼의 정수값을 추가

	            if (mS.getCokenum() < cokenum_in) {
	               JOptionPane.showMessageDialog(null, "수량이 부족합니다.");
	            } else {
	               mS.setCokenum(mS.getCokenum() - cokenum_in);
	               cokemoney = cokemoney + (1000 * cokenum_in);
	               JOptionPane.showMessageDialog(null, cokenum_in + "개가 판매완료되었습니다.");
	               cokecnt = cokecnt + cokenum_in;
	               addLog("콜라가 "+cokenum_in+"개 판매되었습니다.");
	            }
	         } else if (inputDia.equals("라면") || inputDia.equals("2")) {
	            inputDia = JOptionPane.showInputDialog("판매할 수량을 입력하세요.");
	            ramannum_in = Integer.parseInt(inputDia);

	            if (mS.getRamannum() < ramannum_in) {
	               JOptionPane.showMessageDialog(null, "수량이 부족합니다.");
	            } else {
	               mS.setRamannum(mS.getRamannum() - ramannum_in);
	               ramanmoney = ramanmoney + (1500 * ramannum_in);
	               JOptionPane.showMessageDialog(null, ramannum_in + "개가 판매완료되었습니다.");
	               ramancnt = ramancnt + ramannum_in;
	               addLog("라면이 "+ramannum_in+"개 판매되었습니다.");
	            }
	         } else if (inputDia.equals("쿠키") || inputDia.equals("3")) {
	            inputDia = JOptionPane.showInputDialog("판매할 수량을 입력하세요.");
	            cokkienum_in = Integer.parseInt(inputDia);

	            if (mS.getCokkienum() < cokkienum_in) {
	               JOptionPane.showMessageDialog(null, "수량이 부족합니다.");
	            } else {
	               mS.setCokkienum(mS.getCokkienum() - cokkienum_in);
	               cokkiemoney = cokkiemoney + (1200 * cokkienum_in);
	               JOptionPane.showMessageDialog(null, cokkienum_in + "개가 판매완료되었습니다.");
	               cokkiecnt = cokkiecnt + cokkienum_in;
	               addLog("쿠키가 "+cokkienum_in+"개 판매되었습니다.");
	            }
	         } else {
	            JOptionPane.showMessageDialog(null, "올바른 값을 입력해주세요.");
	         }
	           summoney = cokemoney+ramanmoney+cokkiemoney;
	   }
	   
	   void moneyStorage() {   //재고별 메출을 보여주는 함수
	       DecimalFormat formatter = new DecimalFormat("###,###");
	       
	       inputDia = JOptionPane.showInputDialog( "\n1. 콜라 (1,000원)"+ "\n2. 라면 (1,500원)" +  "\n3. 쿠키 (1,200원)" + " \n확인할 메뉴를 고르시오");

	         if (inputDia.equals("콜라") || inputDia.equals("1")) { // 만약 콜라라는 단어를 입력하면

	            JOptionPane.showMessageDialog(null, "콜라 합계 : " + formatter.format(cokemoney) + "원");
	            addLog("콜라의 매출 "+cokemoney+"원이 확인되었습니다.");
	         } else if (inputDia.equals("라면") || inputDia.equals("2")) {
	            JOptionPane.showMessageDialog(null, "라면 합계 : " + formatter.format(ramanmoney) + "원");
	            addLog("라면의 매출 "+ramanmoney+"원이 확인되었습니다.");
	         } else if (inputDia.equals("쿠키") || inputDia.equals("3")) {
	            JOptionPane.showMessageDialog(null, "쿠키 합계 : " + formatter.format(cokkiemoney) + "원");
	            addLog("쿠키의 매출 "+cokkiemoney+"원이 확인되었습니다.");
	         } else if (inputDia.equals("총합") || inputDia.equals("3")) {
	             JOptionPane.showMessageDialog(null, "총 매출 : " + formatter.format(summoney) + "원");
	             addLog("총 매출 "+summoney+"원이 확인되었습니다.");
	          } else {
	            JOptionPane.showMessageDialog(null, "올바른 값을 입력해주세요.");
	         }
	         
	   }

	   
	   void showStorage() {    //메뉴별 잔여수량 보여주는 함수
	       JOptionPane.showMessageDialog(null, "===현재 재고===\n" + cok + mS.getCokenum() + "개" + ram + mS.getRamannum() + "개"
	               + coki + mS.getCokkienum() + "개");
	       addLog("현재 재고가 확인되었습니다.");

	   }
	   
	   void reMoney() {    //환불하는 함수
	          inputDia = JOptionPane.showInputDialog( "\n1. 콜라 (1,000원)"+ "\n2. 라면 (1,500원)" +  "\n3. 쿠키 (1,200원)" + "\n어떤 항목을 환불하시겠습니까?");
	          
	            
	            if (inputDia.equals("콜라") || inputDia.equals("1")) {
	               inputDia = JOptionPane.showInputDialog("몇 개를 환불하시겠습니까?");
	               cokenum_in = Integer.parseInt(inputDia);
	               if(cokecnt < cokenum_in)
	               {
	                  JOptionPane.showMessageDialog(null, "환불수량이 구매한 수량보다  많습니다.");
	               }
	               else {
	               if (cokecnt > 0) {
	                  cokemoney = cokemoney - (1000 * cokenum_in);
	                  mS.setCokenum(mS.getCokenum() + cokenum_in);
	                  JOptionPane.showMessageDialog(null,cokenum_in + "개 환불이 완료되었습니다.");
	                  cokecnt-=cokenum_in;
	                  addLog("콜라가 "+cokenum_in+"개 환불되었습니다.");
	               } 
	               else {
	                  JOptionPane.showMessageDialog(null, "콜라를 구매한 적이 없습니다.");
	               }
	            } }
	            
	            else if (inputDia.equals("라면") || inputDia.equals("2")) {
	               inputDia = JOptionPane.showInputDialog("몇개를 환불하시겠습니까?");
	              ramannum_in = Integer.parseInt(inputDia);
	              if(ramancnt < ramannum_in)
	              {
	                 JOptionPane.showMessageDialog(null, "환불수량이 구매한 수량보다  많습니다.");
	              }
	              else {
	               if (ramancnt > 0) {
	                  ramanmoney = ramanmoney - (1500 * ramannum_in);
	                  mS.setRamannum(mS.getRamannum() + ramannum_in);
	                  JOptionPane.showMessageDialog(null,ramannum_in + "개 환불이 완료되었습니다.");
	                  ramancnt-=ramannum_in;
	                  addLog("라면이 "+ramannum_in+"개 환불되었습니다.");
	               } else {
	                  JOptionPane.showMessageDialog(null, "라면을 구매한 적이 없습니다.");
	               }
	            }}
	            
	            
	            else if (inputDia.equals("쿠키") || inputDia.equals("3")) {
	               inputDia = JOptionPane.showInputDialog("몇개를 환불하시겠습니까?");
	               cokkienum_in = Integer.parseInt(inputDia);
	               if(cokkiecnt<cokkienum_in)
	               {
	                  JOptionPane.showMessageDialog(null, "환불수량이 구매한 수량보다  많습니다.");
	               }
	               else {
	               if (cokkiecnt > 0) {
	                  cokkiemoney = cokkiemoney - (1200 * cokkienum_in);
	                  mS.setCokkienum(mS.getCokkienum() + cokkienum_in);
	                  JOptionPane.showMessageDialog(null, cokkienum_in + "개 환불이 완료 되었습니다.");
	                  cokkiecnt-=cokkienum_in;
	                  addLog("쿠키가 "+cokkienum_in+"개 환불되었습니다.");
	               } else {
	                  JOptionPane.showMessageDialog(null, "쿠키를 구매한 적이 없습니다.");
	               }
	              
	            }
	              
	            }
	            else {
	                JOptionPane.showMessageDialog(null, "올바른 값을 입력해주세요.");
	             }  
	            
	      }

	   void qrCode() { // QR코드를 생성

	       try {
	           String qrCodeData = "\nCoke = " + Integer.toString(mS.getCokenum()) + "\nRamen = "
	                 + Integer.toString(mS.getRamannum()) + "\nCookie = " + Integer.toString(mS.getCokkienum())
	                 + "\nTotal sales = " + (cokemoney + ramanmoney + cokkiemoney) + " won";
	           String filePath = "C:\\jisu\\abc\\qrCode.png"; // qr코드 이미지를 만들 위치 지정
	           String charset = "UTF-8";
	           Map<EncodeHintType, ErrorCorrectionLevel> hintMap = new HashMap<EncodeHintType, ErrorCorrectionLevel>();
	           hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
	           BitMatrix matrix = new MultiFormatWriter().encode(new String(qrCodeData.getBytes(charset), charset),
	                 BarcodeFormat.QR_CODE, 200, 200, hintMap);
	           MatrixToImageWriter.writeToFile(matrix, filePath.substring(filePath.lastIndexOf('.') + 1),
	                 new File(filePath));
	           System.out.println("QR Code 이미지가 성공적으로 생성되었습니다.");
	           addLog("QR Code가 생성되었습니다.");
	        } catch (Exception e) {
	           System.err.println(e);
	        }
	        
	          int Option = JOptionPane.showConfirmDialog(null, "QR코드를 출력하시겠습니까?", "QR코드 출력", JOptionPane.YES_NO_OPTION);
	             if (Option == JOptionPane.YES_OPTION) {
	                   ImageIcon icon = new ImageIcon("C:\\jisu\\abc\\qrCode.png");
	                    JOptionPane.showMessageDialog(null, "QR코드를 출력합니다.", "QR코드 출력", JOptionPane.PLAIN_MESSAGE, icon);
	                    
	                    
	                }
	                else if ((Option == JOptionPane.NO_OPTION) || (Option == JOptionPane.CLOSED_OPTION)) {
	                    return;
	                }

	     }

	   void exit() { // 종료
	//  JOptionPane.showMessageDialog(null, "종료하겠습니다.");
	      int exitOption = JOptionPane.showConfirmDialog(null, "종료하시겠습니까?", "프로그램 종료", JOptionPane.YES_NO_OPTION);
	      if (exitOption == JOptionPane.YES_OPTION) {
	         System.exit(JFrame.EXIT_ON_CLOSE);
	      } else if ((exitOption == JOptionPane.NO_OPTION) || (exitOption == JOptionPane.CLOSED_OPTION)) {
	         return;
	      }

	   }

	}
