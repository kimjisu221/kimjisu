import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Cmain extends JFrame {
	public static void main(String[] args) {
		new Cmain();
	}

	public Cmain() {
		JFrame frame = new JFrame("main");
		frame.setBounds(10, 10, 400, 400);
		frame.setLayout(new BorderLayout());
		frame.setDefaultCloseOperation(frame.DISPOSE_ON_CLOSE);

		JPanel panel1 = new JPanel();
		panel1.setLayout(new FlowLayout());
		ImageIcon img = new ImageIcon("images/logo.jpg");

		JLabel label = new JLabel(img);
		label.setIcon(img);
		panel1.add(label);
		panel1.setBackground(Color.decode("#435676"));

		JPanel panel2 = new JPanel();
		panel2.setLayout(new FlowLayout());
		panel2.setBackground(Color.decode("#435676"));

		JButton b2 = new JButton("���Ͼ���");
		b2.setPreferredSize(new Dimension(100,30)); 

		b2.setBounds(468, 8, 80, 30);
		b2.addActionListener(new Mail());

		JButton b3 = new JButton("�ּҷ�");
		b3.addActionListener(new Gogo());
		b3.setPreferredSize(new Dimension(100,30)); 
		
		b2.setBackground(Color.decode("#B07E7A"));
		b2.setForeground(Color.WHITE);
		b3.setBackground(Color.decode("#B07E7A"));
		b3.setForeground(Color.WHITE);
		panel2.add(b2);
		panel2.add(b3);

		JPanel panel3 = new JPanel();
		panel3.setBackground(Color.decode("#435676"));
		frame.add(panel1, BorderLayout.NORTH);
		frame.add(panel2, BorderLayout.SOUTH);
		frame.add(panel3, BorderLayout.CENTER);

		frame.setVisible(true);

	}

	class Mail implements ActionListener { // ��ư Ű ������ �г� 2�� ȣ��
		@Override
		public void actionPerformed(ActionEvent e) {
			new Mailmain();
		}
	}
	 class Gogo implements ActionListener { // ��ư Ű ������ �г� 2�� ȣ��
	      @Override
	      public void actionPerformed(ActionEvent e) {
	         new Juso();
	      }
	   }
}
