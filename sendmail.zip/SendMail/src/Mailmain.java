import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;

public class Mailmain extends JFrame {
   

   private JFrame jf;

   private JPanel contentPane;

   private JPanel pa;

   private JComboBox co;

   private JComboBox co1;

   public static JTextField textField;

   private JTextField textField_1;

   private JTextArea textArea;

   String[] txt = { "����", "����", "����" };

   private JButton[] jb = new JButton[txt.length];

   private JCheckBox chckbxNewCheckBox;

   String[] fontsizearr = new String[40];

   String[] fontarr = { "Dotum", "Gulim", "Batang", "Gungsuh", "Malgun Gothic" };

   ActionListener[] action = { new BoldFont(), new ItalicFont(), new ColorFont() };

   private boolean check;
   
   private void exit() {

      jf.setVisible(false);
      jf.dispose();
   }
   
    BevelBorder b4 = new BevelBorder(BevelBorder.RAISED);
   
   String ss;
   String write;
   String fontstyle = "<span style = \"font: 2em/1em; color:rgb(0,0,0)\">";
   String fontName="Gothic";
   int fontSize=20;
   int style = Font.PLAIN;
   Font real_style = new Font(fontName,style,fontSize);
   String str_html="";
   
   public Mailmain() {
      jf = new JFrame();
      jf.setTitle("���Ͼ���");
      textArea = new JTextArea();
      textArea.setLineWrap(true);
//      jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      contentPane = new JPanel(new BorderLayout());
      
      JPanel panel1 = new JPanel(new FlowLayout());
      JPanel panel2 = new JPanel(new FlowLayout());
      JPanel panel3 = new JPanel(new GridLayout(2, 1, 5, 5));
      JPanel panel4 = new JPanel(new BorderLayout());
      JPanel panel5 = new JPanel(new GridLayout(2, 1, 5, 5));
      
      pa = new JPanel(new FlowLayout());
      pa.setBackground(Color.decode("#435676"));

      contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
      contentPane.setBackground(Color.decode("#435676"));

      JLabel label = new JLabel("To.");
      label.setForeground(Color.WHITE);
        
      textField = new JTextField(31);
      
      for (int i = 0; i < 40; i++) {
         fontsizearr[i] = Integer.toString(i + 5);
      }

      co = new JComboBox(fontsizearr);
      co1 = new JComboBox(fontarr);
      
      co.addActionListener(new SizeHandler());
      co1.addActionListener(new StyleHandler());
      
      co.setEnabled(false);
      co1.setEnabled(false);
      textField_1 = new JTextField(30);
      
      JLabel label2 = new JLabel("����");
      label2.setForeground(Color.WHITE);
       label2.setBackground(Color.decode("#435676"));
       
       write = str_html;
       
      chckbxNewCheckBox = new JCheckBox("HTML");
      chckbxNewCheckBox.addItemListener(new ItemListener() {
         
         @Override
         public void itemStateChanged(ItemEvent e) {
            // TODO Auto-generated method stub
            if (e.getStateChange() == ItemEvent.SELECTED) {
               for (int i = 0; i < txt.length; i++) {
                  jb[i].setEnabled(true);
               }
               co.setEnabled(true);
               co1.setEnabled(true);
            } else {
               for (int i = 0; i < txt.length; i++) {
                  jb[i].setEnabled(false);
               }
               co.setEnabled(false);
               co1.setEnabled(false);
               fontName="Gothic";
               fontSize=20;
               style=0;
               textArea.setFont(new Font(fontName,style,fontSize));
               textArea.setForeground(Color.BLACK);
               str_html=write;
            }
         }
      });

      JButton addbtn = new JButton("�ּҷ�");
        addbtn.setBackground(Color.decode("#B07E7A"));
        addbtn.setForeground(Color.WHITE);
        addbtn.setBorder(b4);

      addbtn.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            // TODO Auto-generated method stub
            // Ŭ���� newWindow�� ���� ������
            new Juso();

         }

      });
      JButton btnNewButton = new JButton("����");
      btnNewButton.setBackground(Color.decode("#B07E7A"));
       btnNewButton.setForeground(Color.WHITE);
       btnNewButton.setBorder(b4);

      btnNewButton.addMouseListener(new MouseAdapter() {

         @Override

         public void mouseClicked(MouseEvent e) {

            // ���콺Ŭ��

            Go();

         }

      });
      for (int i = 0; i < txt.length; i++) {

         jb[i] = new JButton(txt[i]);
         jb[i].addActionListener(action[i]);
         jb[i].setEnabled(false);
      }

      textArea.setFont(real_style);
      JScrollPane scroll = new JScrollPane(textArea, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
            JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
      
      pa.add(co1);
      for (int i = 0; i < txt.length; i++) {
         pa.add(jb[i]);
      }
      panel1.add(label);
      panel1.add(textField);
      panel2.add(label2);
      panel2.add(textField_1);
      panel3.add(panel1);
      panel3.add(panel2);
      panel4.add(panel3, BorderLayout.CENTER);
      panel5.add(addbtn);
      panel5.add(btnNewButton);
      panel4.add(panel5, BorderLayout.EAST);
      
      panel1.setBackground(Color.decode("#435676"));
       panel2.setBackground(Color.decode("#435676"));
       panel3.setBackground(Color.decode("#435676"));
       panel5.setBackground(Color.decode("#435676"));

      pa.add(co);
      pa.add(chckbxNewCheckBox);
      panel4.add(pa, BorderLayout.SOUTH);
      contentPane.add(panel4, BorderLayout.NORTH);
      contentPane.add(scroll, BorderLayout.CENTER);
      jf.add(contentPane);
      jf.setSize(450, 470);
      jf.setVisible(true);

   }

   public static void main(String[] args) {
      new Mailmain();
   }

   public void Go() {
      System.out.println("GO");

      Mailgo go = new Mailgo();

      check = chckbxNewCheckBox.isSelected();

      String arr[] = textField.getText().split(",");
      System.out.println(str_html);
      str_html=str_html.replace("\">","\">"+textArea.getText());
      System.out.println(str_html);
      boolean result = go.SendMail(arr, textField_1.getText(), str_html, check);

      if (result) {
         JOptionPane.showMessageDialog(Mailmain.this, " ���۵Ǿ����ϴ�.");
         textField.setText("");

         textField_1.setText("");

         textArea.setText("");
         
         textArea.setForeground(Color.BLACK);
      } else {
         JOptionPane.showMessageDialog(Mailmain.this, " ���۽���.");
      }

   }

   class BoldFont implements ActionListener {
      int count = 1;
      int x = 0;

      public void actionPerformed(ActionEvent e) {
    	  System.out.println(str_html);
         write = str_html;
         System.out.println();
         if (count == 1) // �ѹ� ������ ��
         {
            x = write.indexOf(">");
            if (x == -1) {
               fontstyle = fontstyle.replace("font:", "font:bold ");
               str_html=fontstyle + write + "</span>";
               count = 0;
            } else {
               write = write.substring(x + 1, write.length() - 7);
               fontstyle = fontstyle.replace("font:", "font:bold ");
               str_html=fontstyle + write + "</span>";
               count = 0;
            }
         }

         else if (count == 0) // �ѹ� �� ������ ���� ��
         {
            int x = write.indexOf(">");
            write = write.substring(x + 1, write.length() - 7);
            fontstyle = fontstyle.replace("bold ", "");
            str_html=fontstyle + write + "</span>";
            count = 1;
         }
         System.out.println(style);
         style = style==0||style==2?style+1:style-1;

         System.out.println(style);
         textArea.setFont(new Font(fontName,style,fontSize));
      }
   }

   class ItalicFont implements ActionListener {
      int count = 1;
      int x = 0;

      public void actionPerformed(ActionEvent e) {
         write = str_html;

         if (count == 1) // �ѹ� ������ ��
         {
            x = write.indexOf(">");
            if (x == -1) {
               fontstyle = fontstyle.replace("font:", "font:italic ");
               str_html = fontstyle + write + "</span>";
               count = 0;
            } else {
               write = write.substring(x + 1, write.length() - 7);
               fontstyle = fontstyle.replace("font:", "font:italic ");
               str_html = fontstyle + write + "</span>";
               count = 0;
            }
         }

         else if (count == 0) // �ѹ� �� ������ ���� ��
         {
            int x = write.indexOf(">");
            write = write.substring(x + 1, write.length() - 7);
            fontstyle = fontstyle.replace("italic ", "");
            str_html=fontstyle + write + "</span>";
            count = 1;
         }
         style = style==0||style==1?style+2:style-2;
         textArea.setFont(new Font(fontName,style,fontSize));
      }
   }

   class ColorFont implements ActionListener
    {         
       JColorChooser chooser = new JColorChooser(); // �÷� ���̾�α� ����
       Color selectedColor;
       String c,c2;
       int count=1;
       int x = 0;
       int y = 0;      //(�� ��ġ
       int z = 0;
       int k = 0;
       String r,g,b;
       
       public void actionPerformed(ActionEvent e)
       {
           write = str_html;
           String cmd = e.getActionCommand(); //�޴� �������� �̸� ����
           if(cmd.equals("����"))
           { // Color �޴� �������� ���
               // �÷� ���̾�α׸� ����ϰ� ����ڰ� ������ ���� �˾ƿ´�.                
               selectedColor = chooser.showDialog(null,"Color",Color.YELLOW);
               // ����ڰ� ��� ��ư�� �����ų� �׳� ���̾�α׸� �ݴ� ��쿡 selectedColor�� null�̴�.
               if(selectedColor != null) 
                   textArea.setForeground(selectedColor); // ����ڰ� ������ ���� ���ڿ� ������ �����Ѵ�.
           }
           c=selectedColor.toString();
           c=c.substring(15,c.length()-1);   //co: rgb��co=selectedColor.toString();
           System.out.println(selectedColor);
           System.out.println(c);
           
           k = c.indexOf(",");
           System.out.println(k);
           c2=c.substring(2,k);
           System.out.println(c2);
           r=c2;
           
           c=c.substring(k+1,c.length());
           System.out.println(c);
           k = c.indexOf(",");
           c2=c.substring(2,k);
           System.out.println(c2);
           g=c2;
           
           c=c.substring(k+1,c.length());
           System.out.println(c);
           c2=c.substring(2,c.length());
           System.out.println(c2);
           b=c2;
           
           write = str_html;
         
           x = write.indexOf(">");
           y = fontstyle.indexOf("(");
           z = fontstyle.indexOf(")");
         
           if(x==-1)
           {
              fontstyle=fontstyle.substring(0,fontstyle.length()-(fontstyle.length()-y-1));
              fontstyle=fontstyle.replace("(", "("+r+","+g+","+b+")\">");
              str_html=fontstyle+write+"</span>";
           }
           else
           {
              write = write.substring(x+1,write.length()-7);
              fontstyle=fontstyle.substring(0,fontstyle.length()-(fontstyle.length()-y-1));
              fontstyle=fontstyle.replace("(", "("+r+","+g+","+b+")\">");
             str_html=fontstyle+write+"</span>";
           }
       }
   }
   class StyleHandler implements ActionListener {
      int x = 0; // <span>�� ������ ��ġ
      int y = 0; // <span>���� /�� ��ġ
      int z = 0; // <span>���� ;�� ��ġ

      @Override
      public void actionPerformed(ActionEvent e) {
         // TODO Auto-generated method stub
         JComboBox adjust = (JComboBox) e.getSource();
         write = str_html;

         JComboBox box = (JComboBox) e.getSource();
         int num = box.getSelectedIndex();
         String str = fontarr[num];

         x = write.indexOf(">");
         y = write.indexOf("/");
         z = write.indexOf(";");

         if (x == -1) {
            fontstyle = fontstyle.replace("/1em ", "/1em " + str + " ");
            str_html=fontstyle + write + "</span>";
         } else {
            ss = fontstyle.substring(y + 1, z);
            write = write.substring(x + 1, write.length() - 7);
            fontstyle = fontstyle.replace(ss, "1em " + str + " ");
            str_html=fontstyle + write + "</span>";
         }
         fontName=str;
         textArea.setFont(new Font(fontName,style,fontSize));
      }
   }

   class SizeHandler implements ActionListener {
      int count = 1;
      int x = 0;
      int y = 0;
      int z = 0;

      String text;

      @Override
      public void actionPerformed(ActionEvent e) {
         // TODO Auto-generated method stub
         JComboBox adjust = (JComboBox) e.getSource();

         write = str_html;
         x = write.indexOf(">");

         JComboBox box = (JComboBox) e.getSource();
         int num = box.getSelectedIndex();
         String str = fontsizearr[num];

         if (x == -1) {
            y = fontstyle.indexOf("/"); // fontstyle���� / �ձ��� �ڸ���
            text = fontstyle.substring(0, y); // text�� ����

            ss = text.replaceAll("[^0-9]", ""); // �ڸ� fontstyle���� ���� ã��

            text = text.replace(ss, str); // text���� Ŭ�� ���� ���� �� �ٲٱ�

            fontstyle = text.concat(fontstyle.substring(y, fontstyle.length()));
            str_html = fontstyle + write + "</span>";
            count = 0;
         }

         else {
            y = write.indexOf("/");
            text = write.substring(0, y);

            ss = text.replaceAll("[^0-9]", "");

            text = text.replace(ss, str);

            write = text.concat(write.substring(y, write.length()));
            str_html=write;
            count = 0;
         }
         fontSize=Integer.parseInt(str)+10;
         textArea.setFont(new Font(fontName,style,fontSize));
         
      }
   }

}