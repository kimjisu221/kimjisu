import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Mailgo {

	private String fromEmail = "cltkgo1016@gmail.com";

	private String password = "duwk7697^^";

	String toEmail;

	String toName;

	String subject;

	String content;

	boolean result = false;

	public Mailgo() {

		Properties pros = new Properties();

		pros.put("mail.smtp.starttls", "true");

		pros.put("mail.transport.protocol", "smtp");

		pros.put("mail.smtp.host", "smtp.gmail.com");

		pros.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");

		pros.put("mail.smtp.port", "465");

		pros.put("mail.smtp.auth", "true");

		// ����ȯ��

		MyAuth auth = new MyAuth(fromEmail, password);

		Session sess = Session.getDefaultInstance(pros, auth);
	}

	public boolean SendMail(String[] toEmail, String subject, String content, Boolean check) {
		InternetAddress[] addArray = new InternetAddress[toEmail.length];
		for (int i = 0; i < toEmail.length; i++) {
			String[] temp = toEmail[i].split("/");
			if (temp.length < 2) {
				try {
					addArray[i] = new InternetAddress(temp[0], " ", "EUC-KR");
				} catch (UnsupportedEncodingException e) {
					System.out.println("���ڵ�����");
					e.printStackTrace();
				}
			} else {
				try {
					addArray[i] = new InternetAddress(temp[1], temp[0], "EUC-KR");
				} catch (UnsupportedEncodingException e) {
					System.out.println("���ڵ�����");
					e.printStackTrace();
				}
			}
		}

		try {

			// ����ȯ��

			Properties pros = new Properties();

			pros.put("mail.smtp.starttls", "true");

			pros.put("mail.transport.protocol", "smtp");

			pros.put("mail.smtp.host", "smtp.gmail.com");

			pros.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");

			pros.put("mail.smtp.port", "465");

			pros.put("mail.smtp.auth", "true");

			// ����ȯ��

			MyAuth auth = new MyAuth(fromEmail, password);

			Session sess = Session.getDefaultInstance(pros, auth);

			// �޼��� ����

			MimeMessage msg = new MimeMessage(sess);

			msg.setHeader("content-type", "text/plain;charset=EUC-KR");

			// �������
			msg.addRecipients(Message.RecipientType.TO, addArray);

			// ��������

			msg.setSubject(subject);

			// ��������

			if (check == true) {
				System.out.println(content);
				msg.setContent(content, "text/html;charset=EUC-KR");

			} else {
				msg.setContent(content, "text/plain;charset=EUC-KR");

			}
			DateFormat sdFormat = new SimpleDateFormat("yy��MM��dd��HH��mm��ss��");
			Date date = new java.util.Date();
			String str_date = sdFormat.format(date);
			msg.setSentDate(date);
			Transport.send(msg);
			result = true;

			try {
				OutputStream output = new FileOutputStream("C:/SUBIN/store_mail/" + str_date + ".txt");
				String person = "";
				for (int i = 0; i < toEmail.length; i++) {
					if (i == toEmail.length - 1)
						person += toEmail[i] + "\n";
					else
						person += toEmail[i] + ",";
				}
				String str = "�޴»��:" + person + "����: " + subject + "\n����: " + content + "\n���� �ð�:" + str_date;
				byte[] by = str.getBytes();
				output.write(by);
				output.close();

				BufferedWriter bw = new BufferedWriter(new FileWriter("C:/SUBIN/store_mail/mailbox.txt", true));
				PrintWriter pw = new PrintWriter(bw, true);
				for (int i = 0; i < toEmail.length; i++) {
					if (i == toEmail.length - 1)
						pw.write(toEmail[i]);
					else
						pw.write(toEmail[i] + "#");
				}
				pw.write("&" + subject);
				pw.write("^" + str_date + "\n");
				pw.flush();
				pw.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println("���� ���� ����");
				e.printStackTrace();
			}

		} catch (MessagingException e) {

			// TODO Auto-generated catch block
			System.out.println("���۽���");
			e.printStackTrace();

		}
		return result;

	}

}