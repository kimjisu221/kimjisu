import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

public class Juso extends JFrame {

   // first settings

   private JFrame fr = new JFrame("Address Book");

   private JPanel p1;
   private JPanel p2;
   private JPanel p3;
   private JPanel sub_p1;

   // elements

   private JTextField search_name;
   private JTextField store_name;
   private JTextField store_email;

   String[] txt = { "All", "search", "Save", "Delete", "Clear", "Choice", "Exit" };

   private JButton[] b = new JButton[txt.length]; // �迭�� ũ�Ⱑ �ؽ�Ʈ �迭 ������ ��ư��ü

   String result = "";
   String key_result = "";
   
   BevelBorder b4 = new BevelBorder(BevelBorder.RAISED);
   
   HashMap<String, String> dic = new HashMap<String, String>();
   HashMap<String, String> ch_box = new HashMap<String, String>();
   Set<String> keys;
   Iterator<String> it;

   Juso() {
      fr.setLayout(new BorderLayout());// gap is 5

      p1 = new JPanel(new BorderLayout());
      sub_p1 = new JPanel(new GridLayout(1, 2, 5, 5));
      sub_p1.setBorder(new EmptyBorder(10, 10, 10, 10));
      sub_p1.setBorder(new TitledBorder(null, "�Է�", TitledBorder.LEADING, TitledBorder.TOP, null, Color.WHITE));

      p2 = new JPanel(new GridLayout(txt.length, 1, 6, 6));
      p2.setBorder(new EmptyBorder(5, 5, 5, 5));
      p2.setBackground(Color.decode("#435676"));
      p3 = new JPanel();

      inputStream();

      p3.setLayout(new GridLayout(dic.size(), 1, 5, 5));
      
      p3.setBackground(Color.decode("#6C6A7F"));
      
      MyActionListenter mal = new MyActionListenter(); // listener

      for (int i = 0; i < b.length; i++) {

         b[i] = new JButton(txt[i]); // button

         b[i].addActionListener(mal); // add the listener
         b[i].setBackground(Color.decode("#B07E7A"));
         b[i].setForeground(Color.WHITE);
         b[i].setBorder(b4);
      }

      search_name = new HintTextField("�̸��� �Է����ּ���");

      search_name.addMouseListener(new MouseAdapter() {
         @Override
         public void mouseClicked(MouseEvent e) {
            search_name.setFocusable(true);
            for (Component component : p3.getComponents()) {
               component.setEnabled(false);
            }
         }
      });
      store_name = new HintTextField("�̸�");
      store_email = new HintTextField("�̸���");
      keys = dic.keySet();
      it = keys.iterator();
      while (it.hasNext()) {
         String key = it.next();

         String value = dic.get(key);

         JCheckBox box = new JCheckBox(key + "," + value);
         box.setBackground(Color.decode("#6C6A7F"));
         box.setForeground(Color.WHITE);
         box.addItemListener(new CheckItem(box));

         p3.add(box);

      }

      JScrollPane scroll = new JScrollPane(p3, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
            JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
      scroll.setBackground(Color.decode("#6C6A7F"));

      for (int i = 0; i < b.length; i++) {
         p2.add(b[i]);
      }

      sub_p1.add(search_name);
      sub_p1.setBackground(Color.decode("#435676"));
      search_name.setFocusable(false);
      p1.add(sub_p1, BorderLayout.NORTH);
      p1.add(scroll, BorderLayout.CENTER);
      fr.add(p1, BorderLayout.CENTER);
      fr.add(p2, BorderLayout.EAST);
      fr.setSize(400, 300);
      fr.setVisible(true);
   }

   class MyActionListenter implements ActionListener {
      @Override

      public void actionPerformed(ActionEvent e) {

         JButton btn = (JButton) e.getSource();

         for (int i = 0; i < txt.length; i++) {

            if (btn.getText().equals(txt[i])) {

               int ITEM = i;

               choiceAction(ITEM);

            }

         }

      }

   }

   class CheckItem implements ItemListener {
      JCheckBox box;

      CheckItem(JCheckBox box) {
         this.box = box;
      }

      @Override
      public void itemStateChanged(ItemEvent e) {

         String str = "";
         String arr[] = new String[2];
         str += box.getText();
         arr = str.split(",");
         if (box.isSelected()) {
            ch_box.put(arr[0], arr[1]);
            System.out.println(ch_box);
         } else {// �̸��� �����ϸ�
            if (ch_box.containsKey(arr[0])) {
               ch_box.remove(arr[0]);

               System.out.println("������ �Ϸ�Ǿ����ϴ�.");// check
               System.out.println(ch_box);
            }
         }
      }
   }

   class HintTextField extends JTextField {
      public HintTextField(final String hint) {
         setText(hint);
         setForeground(Color.GRAY);
         this.addFocusListener(new FocusAdapter() {

            @Override
            public void focusGained(FocusEvent e) {
               ch_box.clear();
               for (Component component : p3.getComponents()) {
                  component.setEnabled(false);
               }
               if (getText().equals(hint))
                  setText("");
               else
                  setText(getText());
            }

            @Override
            public void focusLost(FocusEvent e) {
               if (getText().equals(hint) || getText().length() == 0) {
                  setText(hint);
                  setForeground(Color.GRAY);
               } else {
                  setText(getText());
                  setForeground(Color.BLACK);
               }
            }
         });
      }
   }

   private void inputStream() {

      try {

         BufferedReader in = new BufferedReader(new FileReader("C:\\\\jsp/test2.txt"));

         String s;

         System.out.println("-----------txt������ ������----------");

         while ((s = in.readLine()) != null) {

            System.out.println(s); // check

            StringTokenizer st = new StringTokenizer(s, "#");

            int n = st.countTokens();

            for (int k = 0; k < n; k++) {

               divideTxt(st.nextToken());

            }

         }

         System.out.println("-------------------------------");

         in.close();// file close

      } catch (IOException e) {

         System.out.println("����� ����");

      }

   }

   private void outputStream() {

      keys = dic.keySet();

      it = keys.iterator();

      try {

         BufferedWriter out = new BufferedWriter(new FileWriter("C:\\\\jsp/test2.txt"));

         while (it.hasNext()) {

            String key = it.next();

            String value = dic.get(key);

            String all = key + "%" + value + "#";

            out.write(all);
            out.newLine();

         }

         out.close();

      } catch (IOException e) {

         System.out.println("����� ����");//

      }

   }

   private void divideTxt(String beforetxt) {

      StringTokenizer st = new StringTokenizer(beforetxt, "%");

      String key = st.nextToken();

      String value = st.nextToken();

      dic.put(key, value);

   }

   private void choiceAction(int item) {

      switch (item) {

      case 0:
         refresh(dic);
         sub_p1.removeAll();
         search_name = new JTextField("�̸��� �Է����ּ���");
         sub_p1.add(search_name);
         sub_p1.revalidate();
         break;

      case 1:
         search();
         break;

      case 2:
         save();
         break;

      case 3:
         delete();
         break;

      case 4:

         clear();
         break;

      case 5:
         choice();
         break;

      case 6:
         exit();
         break;

      }

   }

   // function
   private void saveInput() {
      sub_p1.removeAll();
      sub_p1.setLayout(new GridLayout());
      store_name = new HintTextField("�̸�");
      store_email = new HintTextField("�̸���");
      sub_p1.add(store_name);
      sub_p1.add(store_email);
      sub_p1.revalidate();
   }

   private void searchInput() {
      sub_p1.removeAll();
      sub_p1.setLayout(new GridLayout());
      search_name = new HintTextField("�̸��� �Է����ּ���");
      sub_p1.add(search_name);
      sub_p1.revalidate();
   }

   private void refresh(HashMap<String, String> hashmap) {
      p3.removeAll();
      p3.setLayout(new GridLayout(hashmap.size(), 1, 5, 5));

      keys = hashmap.keySet();
      it = keys.iterator();
      while (it.hasNext()) {
         String key = it.next();
         String value = dic.get(key);
         JCheckBox box = new JCheckBox(key + "," + value);
         box.addItemListener(new CheckItem(box));
         box.setBackground(Color.decode("#6C6A7F"));
         box.setForeground(Color.WHITE);
         p3.add(box);
      }
      p3.revalidate();
   }

   private void save() {
      refresh(dic);
      System.out.println(sub_p1.getComponentCount());
      if (sub_p1.getComponentCount() == 1) {
         saveInput();
         return;
      }
      String name = store_name.getText();

      String email = store_email.getText();
      if (name.equals("") || email.equals("")) {
         System.out.println("Null�� ����Ұ�");
         return;
      }
      dic.put(name, email);
      System.out.println("����Ϸ�"); // check

      outputStream();
      inputStream();
      refresh(dic);
      searchInput();
   }

   private void delete() {

      try {
         keys = ch_box.keySet();
         it = keys.iterator();
         while (it.hasNext()) {
            String key = it.next();
            if (dic.containsKey(key)) {// �̸��� �����ϸ�
               dic.remove(key);
               System.out.println("������ �Ϸ�Ǿ����ϴ�.");
            } else {
               System.out.println("�������� �ʴ� �̸��Դϴ�.");
               return;
            }
         }
         outputStream();
         inputStream();
         refresh(dic);
         ch_box.clear();

      } catch (NullPointerException e) {
         System.out.println("NullPointerException");
      }

   }

   private void search() {
      System.out.println(sub_p1.getComponentCount());
      if (sub_p1.getComponentCount() != 1) {
         searchInput();
         return;
      }
      try {

         String name = search_name.getText();
         keys = dic.keySet();
         it = keys.iterator();
         while (it.hasNext()) {
            String key = it.next();
            String value = dic.get(key);
            if (key.equals(name)) {// �̸��� �����ϸ�
               ch_box.put(key, value);
               System.out.println(key);
            }
         }
         refresh(ch_box);
         ch_box.clear();
      } catch (NullPointerException e) {
         System.out.println("NullPointerException");
      }

   }

   private void clear() {

      try {

         search_name.setText("");
         store_name.setText("");
         store_email.setText("");

         System.out.println("����� �Ϸ�");// check

      } catch (NullPointerException e) {

         System.out.println("NullPointerException");

      }

   }

   private void choice() {
      keys = ch_box.keySet();
      it = keys.iterator();
      while (it.hasNext()) {
         String key = it.next();
         String value = ch_box.get(key);
         if (!it.hasNext()) {
            result += key + "/" + value;

         } else {
            result += key + "/" + value + ",";
         }
      }
      System.out.println(result);
      if (!Mailmain.textField.getText().equals("")) {
         result = Mailmain.textField.getText() + "," + result;
      }
      Mailmain.textField.setText(result);
      fr.setVisible(false);
      fr.dispose();

   }

   public static void main(String[] args) {
      new Juso();
   }

   private void exit() {
      fr.setVisible(false);
      fr.dispose();

   }

}