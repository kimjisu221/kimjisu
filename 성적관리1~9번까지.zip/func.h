
int func1();
int func2();
void func3();
int func4();
int func5();
int func6();
int func7();
void func8();
void func9();
void func10(); 
void func11();